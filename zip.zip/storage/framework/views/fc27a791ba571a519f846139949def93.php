<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\xampp2\htdocs\PROJECTS\SantiagoProject\santiagobackend\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>