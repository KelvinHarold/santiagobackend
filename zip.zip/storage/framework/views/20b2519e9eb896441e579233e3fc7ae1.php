<h2>Today's Sales Summary</h2>
<h2>Match:<?php echo e($report->match_name); ?></h2>
<p>Date: <?php echo e($report->report_date->format('Y-m-d')); ?></p>

<h3>Attendance</h3>
<ul>
    <li>Main Hall People: <?php echo e($report->attendances->main_hall_people); ?></li>
    <li>Main Hall Staff: <?php echo e($report->attendances->main_hall_staff); ?></li>
    <li>VIP Hall People: <?php echo e($report->attendances->vip_hall_people); ?></li>
    <li>VIP Hall Staff: <?php echo e($report->attendances->vip_hall_staff); ?></li>
</ul>

<h3>Expenses</h3>
<ul>
<?php $__currentLoopData = $report->expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><?php echo e($exp->title); ?>: <?php echo e(number_format($exp->amount, 2)); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<p><strong>Total Expenses:</strong> <?php echo e(number_format($report->expenses->sum('amount'), 2)); ?></p>
<p><strong>Total Income:</strong> <?php echo e(number_format($report->total_income, 2)); ?></p>
<p><strong>Remaining Balance:</strong> <?php echo e(number_format($report->remaining_balance, 2)); ?></p>

<h3>Revenue Shares</h3>
<ul>
<?php $__currentLoopData = $report->revenueShares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $share): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><?php echo e($share->user->name); ?> (<?php echo e($share->percentage); ?>%): <?php echo e(number_format($share->amount, 2)); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php /**PATH C:\xampp2\htdocs\SantiagoProject\santiagobackend\resources\views/emails/daily_report_summary.blade.php ENDPATH**/ ?>