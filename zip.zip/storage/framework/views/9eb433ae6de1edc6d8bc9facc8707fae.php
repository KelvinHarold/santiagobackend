<?php echo e($slot); ?>

<?php /**PATH C:\xampp2\htdocs\PROJECTS\SantiagoProject\santiagobackend\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>